# Cricket Tournament Platform

Standalone cricket tournament registration and auction platform built with Next.js 16, Supabase and Vercel.

## Current MVP

- Admin email/password login through Supabase Auth
- Tournament creation and branding
- Tournament logo upload through Supabase Storage
- Public tournament page
- Public player registration
- CricHeroes profile URL capture
- Admin tournament status controls
- Initial auction configuration (category/open, base price, bid increment, purse)

## 1. Supabase

Run the database schema from the project conversation first. Then run `supabase/002_storage.sql` in Supabase SQL Editor.

Create an admin in Supabase Authentication and add the same user UUID to `public.admin_profiles`.

## 2. Environment variables

Create `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
```

Never add a Supabase secret/service-role key to the repository.

## 3. Install and run

```bash
npm install
npm run dev
```

## 4. Deploy to Vercel

Import this GitHub repository into Vercel, then add the same two environment variables in Project Settings → Environment Variables.

Deploy. Vercel will build the Next.js application automatically.

## Public URLs

- `/` landing page
- `/login` admin login
- `/admin` admin dashboard
- `/t/<slug>` public tournament
- `/t/<slug>/register` player registration
