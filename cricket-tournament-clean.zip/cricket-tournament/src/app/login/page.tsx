'use client'
import { FormEvent, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import Nav from '@/components/Nav'
import { createClient } from '@/lib/supabase/client'

export default function Login(){
  const router=useRouter(); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [error,setError]=useState(''); const [loading,setLoading]=useState(false)
  async function submit(e:FormEvent){e.preventDefault();setError('');setLoading(true);const supabase=createClient();const {error}=await supabase.auth.signInWithPassword({email,password});if(error){setError(error.message);setLoading(false);return}router.push('/admin');router.refresh()}
  return <><Nav/><main className="container"><div className="card form-card"><h1>Admin Login</h1><p className="muted">Sign in to manage tournaments and player registrations.</p>{error&&<div className="error">{error}</div>}<form onSubmit={submit}>
    <div className="field-group"><label className="label">Email</label><input className="field" type="email" required value={email} onChange={e=>setEmail(e.target.value)}/></div>
    <div className="field-group"><label className="label">Password</label><input className="field" type="password" required value={password} onChange={e=>setPassword(e.target.value)}/></div>
    <button className="btn btn-primary" disabled={loading}>{loading?'Signing in…':'Sign in'}</button>
  </form><p className="small muted" style={{marginTop:18}}><Link href="/">← Back to home</Link></p></div></main></>
}
