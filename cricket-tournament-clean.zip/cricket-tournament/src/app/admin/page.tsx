import Link from 'next/link'
import { redirect } from 'next/navigation'
import Nav from '@/components/Nav'
import LogoutButton from '@/components/LogoutButton'
import { createClient } from '@/lib/supabase/server'

export default async function AdminPage(){
  const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser();
  if(!user) redirect('/login')
  const {data:admin}=await supabase.from('admin_profiles').select('full_name,role').eq('id',user.id).maybeSingle()
  if(!admin) redirect('/login')
  const {data:tournaments,error}=await supabase.from('tournaments').select('id,name,slug,status,logo_url,created_at').order('created_at',{ascending:false})
  return <><Nav admin/><main className="container"><div className="page-title"><div className="toolbar"><div><h1>Admin Dashboard</h1><p className="muted">Welcome, {admin.full_name||user.email}</p></div><div style={{display:'flex',gap:8}}><Link className="btn btn-primary" href="/admin/tournaments/new">+ Create Tournament</Link><LogoutButton/></div></div></div>
    {error&&<div className="error">{error.message}</div>}
    <div className="card"><div className="toolbar"><div><h2 style={{margin:0}}>Your tournaments</h2><p className="muted">Create and manage independent tournaments.</p></div></div>
      {(!tournaments||tournaments.length===0)?<div className="center muted" style={{padding:40}}>No tournaments yet. Create your first tournament.</div>:<div className="table-wrap"><table className="table"><thead><tr><th>Tournament</th><th>Status</th><th>Public URL</th><th></th></tr></thead><tbody>{tournaments.map(t=><tr key={t.id}><td><strong>{t.name}</strong><div className="small muted">/{t.slug}</div></td><td><span className={'badge '+(t.status==='registration_open'?'badge-green':'')}>{t.status}</span></td><td><Link className="btn btn-secondary" href={`/t/${t.slug}`} target="_blank">Open</Link></td><td><Link className="btn btn-ghost" href={`/admin/tournaments/${t.id}`}>Manage</Link></td></tr>)}</tbody></table></div>}
    </div></main></>
}
