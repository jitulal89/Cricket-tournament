'use client'
import { FormEvent, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import Nav from '@/components/Nav'
import { createClient } from '@/lib/supabase/client'

function slugify(value:string){return value.toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'')}

export default function NewTournament(){
 const router=useRouter(); const [name,setName]=useState(''); const [slug,setSlug]=useState(''); const [description,setDescription]=useState(''); const [status,setStatus]=useState<'draft'|'registration_open'>('draft'); const [logo,setLogo]=useState<File|null>(null); const [error,setError]=useState(''); const [loading,setLoading]=useState(false)
 async function submit(e:FormEvent){e.preventDefault();setError('');setLoading(true);const supabase=createClient();const {data:{user}}=await supabase.auth.getUser();if(!user){router.push('/login');return}
   const finalSlug=slugify(slug||name); if(!finalSlug){setError('Enter a tournament name.');setLoading(false);return}
   let logoUrl:string|null=null
   if(logo){const ext=logo.name.split('.').pop()?.toLowerCase()||'png';const path=`${finalSlug}-${crypto.randomUUID()}.${ext}`;const up=await supabase.storage.from('tournament-logos').upload(path,logo,{upsert:false,contentType:logo.type});if(up.error){setError(`Logo upload failed: ${up.error.message}`);setLoading(false);return}logoUrl=supabase.storage.from('tournament-logos').getPublicUrl(path).data.publicUrl}
   const {data:t,error:tErr}=await supabase.from('tournaments').insert({name,slug:finalSlug,description:description||null,logo_url:logoUrl,status,created_by:user.id}).select('id,slug').single();
   if(tErr){setError(tErr.message);setLoading(false);return}
   const {error:rErr}=await supabase.from('registration_forms').insert({tournament_id:t.id}); if(rErr){setError(rErr.message);setLoading(false);return}
   const {error:aErr}=await supabase.from('auction_settings').insert({tournament_id:t.id}); if(aErr){setError(aErr.message);setLoading(false);return}
   router.push(`/admin/tournaments/${t.id}`);router.refresh()
 }
 return <><Nav admin/><main className="container"><div className="page-title"><h1>Create Tournament</h1><p className="muted">Set up the tournament branding and public registration foundation.</p></div><div className="card form-card"><form onSubmit={submit}>{error&&<div className="error">{error}</div>}
  <div className="field-group"><label className="label">Tournament name *</label><input className="field" required value={name} onChange={e=>{setName(e.target.value);if(!slug)setSlug(slugify(e.target.value))}} placeholder="e.g. City Premier League"/></div>
  <div className="field-group"><label className="label">Public URL slug *</label><input className="field" required value={slug} onChange={e=>setSlug(slugify(e.target.value))}/><div className="small muted" style={{marginTop:6}}>Your registration URL will use /t/{slug||'your-tournament'}/register</div></div>
  <div className="field-group"><label className="label">Tournament logo</label><div className="upload"><input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" onChange={e=>setLogo(e.target.files?.[0]||null)}/>{logo&&<div className="small muted" style={{marginTop:8}}>{logo.name}</div>}</div></div>
  <div className="field-group"><label className="label">Description</label><textarea className="field" rows={4} value={description} onChange={e=>setDescription(e.target.value)} placeholder="Short description shown on the public tournament page."/></div>
  <div className="field-group"><label className="label">Initial status</label><select className="field" value={status} onChange={e=>setStatus(e.target.value as typeof status)}><option value="draft">Draft</option><option value="registration_open">Open registration now</option></select></div>
  <div style={{display:'flex',gap:10}}><button className="btn btn-primary" disabled={loading}>{loading?'Creating…':'Create Tournament'}</button><Link className="btn btn-ghost" href="/admin">Cancel</Link></div>
 </form></div></main></>
}
