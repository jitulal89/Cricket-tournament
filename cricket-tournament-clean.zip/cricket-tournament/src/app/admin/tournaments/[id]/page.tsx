import { notFound, redirect } from 'next/navigation'
import Link from 'next/link'
import Nav from '@/components/Nav'
import LogoutButton from '@/components/LogoutButton'
import TournamentManager from '@/components/TournamentManager'
import { createClient } from '@/lib/supabase/server'

export default async function ManageTournament({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user) redirect('/login');
 const {data:admin}=await supabase.from('admin_profiles').select('id').eq('id',user.id).maybeSingle(); if(!admin) redirect('/login')
 const {data:tournament,error}=await supabase.from('tournaments').select('*').eq('id',id).single(); if(error||!tournament) notFound()
 const {data:form}=await supabase.from('registration_forms').select('*').eq('tournament_id',id).maybeSingle()
 const {data:auction}=await supabase.from('auction_settings').select('*').eq('tournament_id',id).maybeSingle()
 const {count:players}=await supabase.from('player_registrations').select('id',{count:'exact',head:true}).eq('tournament_id',id)
 const {count:approved}=await supabase.from('player_registrations').select('id',{count:'exact',head:true}).eq('tournament_id',id).eq('status','approved')
 const {count:teams}=await supabase.from('teams').select('id',{count:'exact',head:true}).eq('tournament_id',id)
 return <><Nav admin/><main className="container"><div className="page-title"><div className="toolbar"><div><div className="small muted"><Link href="/admin">← Admin Dashboard</Link></div><h1>{tournament.name}</h1><p className="muted">/{tournament.slug}</p></div><div style={{display:'flex',gap:8}}><Link className="btn btn-secondary" href={`/t/${tournament.slug}`} target="_blank">Public Page</Link><LogoutButton/></div></div></div>
  <div className="stat-grid"><div className="card stat"><span>Registrations</span><strong>{players||0}</strong></div><div className="card stat"><span>Approved</span><strong>{approved||0}</strong></div><div className="card stat"><span>Teams</span><strong>{teams||0}</strong></div><div className="card stat"><span>Status</span><strong style={{fontSize:18}}>{tournament.status}</strong></div></div>
  <TournamentManager tournament={tournament} form={form} auction={auction}/>
 </main></>
}
