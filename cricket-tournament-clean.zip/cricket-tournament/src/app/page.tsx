import Link from 'next/link'
import Nav from '@/components/Nav'

export default function Home(){
  return <>
    <Nav />
    <main>
      <section className="hero"><div className="container hero-grid">
        <div>
          <div className="eyebrow">Cricket tournament management</div>
          <h1>Run your tournament from registration to auction.</h1>
          <p>Create a tournament, brand it with your own logo, share a public registration link, collect players and prepare them for a points-based team auction.</p>
          <div className="hero-actions"><Link className="btn btn-primary" href="/login">Open Admin</Link></div>
        </div>
        <div className="hero-card">
          <h3>Everything starts with one tournament</h3>
          <div className="feature-list">
            <div className="feature">🏆 Custom tournament branding</div>
            <div className="feature">📝 Public player registration</div>
            <div className="feature">📊 CricHeroes profile links</div>
            <div className="feature">🔨 Category or open auction</div>
            <div className="feature">💰 Team purse management</div>
          </div>
        </div>
      </div></section>
      <section className="section"><div className="container">
        <h2>Built for independent tournaments</h2><p className="muted">Each tournament has its own players, teams, branding, registration form and auction configuration.</p>
        <div className="grid grid-3" style={{marginTop:24}}>
          <div className="card"><h3>Register</h3><p className="muted">Share one public link and collect player information including CricHeroes profiles.</p></div>
          <div className="card"><h3>Auction</h3><p className="muted">Create categories with different minimum bids or use one common base price.</p></div>
          <div className="card"><h3>Manage</h3><p className="muted">Approve players, create teams and prepare the tournament for live auction and matches.</p></div>
        </div>
      </div></section>
    </main>
    <footer className="footer"><div className="container">Cricket Tournament Platform</div></footer>
  </>
}
