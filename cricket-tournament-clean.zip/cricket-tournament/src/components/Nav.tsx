import Link from 'next/link'

export default function Nav({ admin = false }: { admin?: boolean }) {
  return <header className="nav"><div className="container nav-inner">
    <Link href="/" className="brand">🏏 Cricket Tournament</Link>
    <nav className="nav-links">
      {admin ? <Link className="btn btn-ghost optional" href="/admin">Dashboard</Link> : <Link className="btn btn-ghost optional" href="/login">Admin Login</Link>}
    </nav>
  </div></header>
}
