'use client'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function LogoutButton(){
  const router=useRouter()
  async function logout(){
    const supabase=createClient(); await supabase.auth.signOut(); router.push('/login'); router.refresh()
  }
  return <button className="btn btn-ghost" onClick={logout}>Sign out</button>
}
