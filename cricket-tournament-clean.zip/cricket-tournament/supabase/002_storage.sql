-- Run this after the main schema if you want tournament logo uploads from the admin UI.

insert into storage.buckets (id, name, public)
values ('tournament-logos', 'tournament-logos', true)
on conflict (id) do update set public = true;

create policy "Public can view tournament logos"
on storage.objects
for select
to anon, authenticated
using (bucket_id = 'tournament-logos');

create policy "Admins can upload tournament logos"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'tournament-logos'
  and public.is_admin()
);

create policy "Admins can update tournament logos"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'tournament-logos'
  and public.is_admin()
)
with check (
  bucket_id = 'tournament-logos'
  and public.is_admin()
);

create policy "Admins can delete tournament logos"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'tournament-logos'
  and public.is_admin()
);
