# Supabase setup

Run the schema supplied during the project setup in the Supabase SQL Editor.

Then run `002_storage.sql` for public tournament logo hosting.

The application intentionally uses the Supabase publishable key only. Do not put a secret/service-role key in GitHub or browser environment variables.
